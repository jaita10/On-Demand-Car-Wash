package com.training.orderservice.model;

public class Location1 {
	
	public static void main(String args[]) {
		
		Location1 longitude = new Location1();
		
		Location1 latitude = new Location1();

		System.out.println(longitude);
		
		System.out.println(latitude);
		
	}

}
